@echo off
cd /d d:\project\server
echo Starting backend server...
node index.js
pause
