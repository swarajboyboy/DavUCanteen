// utils/sendOrderConfirmationEmail.js
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

export const sendOrderConfirmationEmail = async (toEmail, orderDetails) => {
  const mailOptions = {
    from: process.env.SENDER_EMAIL,
    to: toEmail,
    subject: `Order Confirmation - Order #${orderDetails.orderId}`,
    html: `
      <h2>Thank you for your order!</h2>
      <p>Your order <strong>#${orderDetails.orderId}</strong> has been placed successfully.</p>
      <p><strong>Total Paid:</strong> $${orderDetails.orderTotal}</p>
      <p>Your meal is freshly prepared and ready for pickup! 🍽️</p>
<p>Please collect your order within the next 15 minutes from the DAVU Student Center – Canteen Pickup Counter.</p>
<p>DAVU Canteen Team</p>
      <br/>
      <em>@davcanteen.org</em>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`✅ Confirmation email sent to ${toEmail}`);
  } catch (err) {
    console.error('❌ Failed to send confirmation email:', err);
  }
};
