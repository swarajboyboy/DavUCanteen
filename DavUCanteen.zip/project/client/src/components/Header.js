import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import ROUTES from "../navigation/Routes";
import axiosInstance from "../api/axiosInstance.js";
import { address } from "../App";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import davLogo from "../assets/davlogo.png";
import "./Header.css";

function Header() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      getCartCount();
      setIsLoggedIn(true);
      try {
        const decodedToken = jwtDecode(token);
        setIsAdmin(decodedToken.role === "admin");
      } catch {
        setIsLoggedIn(false);
        setIsAdmin(false);
        localStorage.removeItem("token");
        localStorage.removeItem("userData");
      }
    } else {
      setIsLoggedIn(false);
      setIsAdmin(false);
    }

    const handleCartUpdate = () => getCartCount();
    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userData");
    setIsLoggedIn(false);
    setIsAdmin(false);
    navigate(ROUTES.login.name);
  };

  const getCartCount = () => {
    axiosInstance.get(address("cart"))
      .then((d) => setCartCount(d.data.cart.length))
      .catch(() => setCartCount(0));
  };

  return (
    <header className="nav-outer-bar">
      <nav className="nav-flex-bar container">
        {/* -- Absolute left: Logo and branding -- */}
        <div className="nav-brand-side">
          <Link to="/" className="navbar-branding">
            <img
              src={davLogo}
              alt="DavU Logo"
              className="dav-logo"
            />
            <span className="dav-brand-text">
              DavU <span className="dav-brand-accent">Canteen</span>
            </span>
          </Link>
        </div>
        {/* -- Center: Navigation (flex center) -- */}
        <div className="nav-center-side">
          <ul className="nav-center-list">
            <li>
              <Link to="/" className="nav-link">
                <FontAwesomeIcon icon="house" /> <span>Home</span>
              </Link>
            </li>
            {isAdmin ? (
              <>
                <li>
                  <Link to="/universityAdmin" className="nav-link">
                    <FontAwesomeIcon icon="building-columns" />
                    <span>Canteen Management </span>
                  </Link>
                </li>
                <li>
                  <Link to="/orderManagement" className="nav-link">
                    <FontAwesomeIcon icon="clipboard-list" />
                    <span>Order Management</span>
                  </Link>
                </li>
                 <li>
                  <Link to="/about" className="nav-link">
                    <FontAwesomeIcon icon="circle-info" /> <span>About</span>
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="nav-link">
                    <FontAwesomeIcon icon="address-book" /> <span>Contact</span>
                  </Link>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link to="/about" className="nav-link">
                    <FontAwesomeIcon icon="circle-info" /> <span>About</span>
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="nav-link">
                    <FontAwesomeIcon icon="address-book" /> <span>Contact</span>
                  </Link>
                </li>
                <li>
                  <Link to="/userorder" className="nav-link">
                    <FontAwesomeIcon icon="receipt" /> <span>Orders</span>
                  </Link>
                </li>
                <li>
                  <Link to="/support" className="nav-link">
                    <FontAwesomeIcon icon="headset" /> <span></span>
                  </Link>
                </li>
              </>
            )}
            <li>
              <Link to={ROUTES.cart.name} className="nav-link cart-btn">
                <FontAwesomeIcon icon="cart-shopping" />
                <span className="cart-badge">{cartCount}</span>
              </Link>
            </li>
          </ul>
        </div>
        {/* -- Absolute right: Auth actions -- */}
        <div className="nav-auth-side">
          {!isLoggedIn ? (
            <>
              <Link to="/register" className="nav-link btn btn-sm nav-btn-auth nav-btn-register">
                <FontAwesomeIcon icon="user-plus" /> Register
              </Link>
              <Link to="/login" className="nav-link btn btn-sm nav-btn-auth nav-btn-login">
                <FontAwesomeIcon icon="right-to-bracket" /> Login
              </Link>
            </>
          ) : (
            <button
              className="nav-link btn btn-sm nav-btn-auth nav-btn-logout"
              onClick={handleLogout}
            >
              <FontAwesomeIcon icon="sign-out-alt" /> Logout
            </button>
          )}
        </div>
      </nav>
    </header>
  );
}

export default Header;