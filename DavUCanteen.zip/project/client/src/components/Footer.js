import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <footer className="main-footer">
      <div className="footer-container">
        <div className="footer-brand">
          <i className="fa-solid fa-bowl-food footer-logo"></i>
          <span>DavU Canteen</span>
        </div>
        <nav className="footer-nav">
          <a href="/" className="footer-link" aria-label="Home">
            <i className="fa-solid fa-house"></i>
          </a>
          <a href="/about" className="footer-link" aria-label="About">
            <i className="fa-solid fa-info-circle"></i>
          </a>
          <a href="/contact" className="footer-link" aria-label="Contact">
            <i className="fa-solid fa-envelope"></i>
          </a>
          <a href="/support" className="footer-link" aria-label="Support">
            <i className="fa-solid fa-headset"></i>
          </a>
        </nav>
        <div className="footer-social">
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="https://www.instagram.com/dav.university_official/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <i className="fab fa-instagram"></i>
          </a>
          <a href="mailto:support@davu.com" aria-label="Email">
            <i className="fa-solid fa-paper-plane"></i>
          </a>
        </div>
      </div>
      <div className="footer-copy">
        &copy; {new Date().getFullYear()} DavU Canteen
      </div>
    </footer>
  );
}

export default Footer;