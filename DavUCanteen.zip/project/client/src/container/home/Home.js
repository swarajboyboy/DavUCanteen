import React, { useEffect, useState } from "react";
import Header from "../../components/Header";
import axios from "../../api/axiosInstance";
import { address } from "../../App";
import { useNavigate } from "react-router-dom";
import ROUTES from "../../navigation/Routes";
import "./Home.css";

// Modal Component for shop list
function ShopCountModal({ show, onClose, shops }) {
  if (!show) return null;
  return (
    <div className="home-modal-bg" onClick={onClose}>
      <div className="home-modal-card" onClick={e => e.stopPropagation()}>
        <h4>
          <i className="fa-regular fa-file-alt accent"></i> Showing {shops.length} {shops.length === 1 ? "shop" : "shops"}
        </h4>
        <ul>
          {shops.map(s => (
            <li key={s._id}>
              <i className="fa-solid fa-store accent"></i> {s.name}
            </li>
          ))}
        </ul>
        <button className="home-modal-btn" onClick={onClose}><i className="fa-solid fa-xmark"></i> Close</button>
      </div>
    </div>
  );
}

function Home() {
  const [universities, setUniversities] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get(address("university"))
      .then((d) => setUniversities(d.data.uniData))
      .catch((err) => alert(err.message));
  }, []);

  const filteredUniversities = universities.filter(u =>
    u.name.toLowerCase().includes(search.trim().toLowerCase())
  );

  return (
    <div className="home-bg">
      <Header />
      <section className="container home-hero-container">
        <div className="home-hero-header-row">
          <h1 className="home-section-title">
            <i className="fa-solid fa-store"></i> All Shops
          </h1>
          <div
            className="home-hero-count home-hero-count-movable"
            onClick={() => filteredUniversities.length > 0 && setShowModal(true)}
            style={{ cursor: filteredUniversities.length > 0 ? 'pointer' : 'not-allowed' }}>
            <i className="fa-regular fa-file-alt"></i>
            <span className="accent">{filteredUniversities.length}</span>
          </div>
        </div>
        <div className="home-hero">
          <div className="container home-hero-inner">
            <h2 className="home-hero-title">
              <span>
                Search <span className="accent">your choice</span>
              </span>
            </h2>
            <div className="home-hero-searchbox">
              <input
                className="home-hero-search"
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search canteens by name..."
                aria-label="Search canteens"
              />
              <button className="home-hero-search-btn" tabIndex={-1}>
                <i className="fa-solid fa-search"></i>
              </button>
            </div>
          </div>
        </div>
      </section>
      <div className="container">
        <div className="row home-card-row">
          {filteredUniversities.length === 0 ? (
            <div className="col-12 mt-4 text-center home-empty">
              <i className="fa-regular fa-face-frown accent" style={{fontSize:"2.1rem"}}></i>
              <div>No canteen found for your search.</div>
            </div>
          ) : (
            filteredUniversities.map((uni) => (
              <div key={uni._id} className="col-lg-4 col-md-6 col-12 d-flex align-items-stretch">
                <div className="home-card glass">
                  <div className="home-card-img-wrap">
                    <img src={address(uni.image)} alt={uni.name} className="home-card-img"/>
                    <div className="home-card-badge">
                      <i className="fa-solid fa-utensils"></i> Canteen
                    </div>
                  </div>
                  <div className="home-card-content">
                    <div className="home-card-title">
                      <i className="fa-solid fa-building-columns"></i> {uni.name}
                    </div>
                    <button
                      className="home-card-btn"
                      onClick={() => navigate(ROUTES.departmentUser.name + "?id=" + uni._id + "&name=" + encodeURIComponent(uni.name))}
                    >
                      Go to Shop <i className="fa-solid fa-arrow-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      <ShopCountModal show={showModal} onClose={() => setShowModal(false)} shops={filteredUniversities} />
    </div>
  );
}

export default Home;