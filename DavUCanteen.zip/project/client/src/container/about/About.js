// 📄 About.jsx
import React from 'react';
import Header from '../../components/Header';
import { motion } from 'framer-motion';
import "./About.css";

const cards = [
  {
    title: "Our Mission",
    content:
      "To provide students and staff of DAV University with fresh, hygienic, and affordable meals—all delivered with fast service and a friendly environment.",
    icon: "🎯"
  },
  {
    title: "Who We Are",
    content:
      "We are the official DAVU Canteen team dedicated to serving nutritious food, snacks, and beverages to the university community with care and quality.",
    icon: "👨‍🍳"
  },
  {
    title: "Our Vision",
    content:
      "To create a modern, smart, and comfortable food space on campus while ensuring quality, cleanliness, and convenience for everyone at DAV University.",
    icon: "🌟"
  }
];

function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-100 to-yellow-200 text-gray-800">
      <Header />
      <div className="max-w-6xl mx-auto p-6 text-center">
        <h1 className="text-5xl font-bold mb-10 animate-pulse">
          About DAVU Canteen
        </h1>

        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((card, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl"
            >
              <div className="text-5xl mb-4">{card.icon}</div>
              <h2 className="text-2xl font-bold mb-2">{card.title}</h2>
              <p className="text-gray-600">{card.content}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default About;
