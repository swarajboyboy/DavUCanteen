import React, { useState, useEffect } from 'react';
import Header from '../../components/Header.js';
import axiosInstance from '../../api/axiosInstance.js';
import { address } from '../../App.js';
import { useNavigate } from 'react-router-dom';
import toastr from 'toastr';
import ROUTES from '../../navigation/Routes.js';
import './OrderSummary.css'; // <-- new CSS for better visuals

function OrderSummary() {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    fullName: '',
    address: '',
    phone: '',
  });
  const navigate = useNavigate();

  useEffect(() => { fetchOrderSummary(); }, []);

  const fetchOrderSummary = async () => {
    try {
      const response = await axiosInstance.get(address('ordersummary'));
      setCartItems(response.data.cartItems || []);
      setTotal(response.data.total || 0);
      setLoading(false);
    } catch (err) {
      toastr.error("Failed to load order summary.");
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    try {
      const response = await axiosInstance.post(address('ordersubmission'), {
        ...formData,
        successUrl: `http://localhost:3000${ROUTES.orderConfirmation.name}?session_id={CHECKOUT_SESSION_ID}`,
        cancelUrl: `http://localhost:3000${ROUTES.orderSummary.name}`,
      });
      if (response.data.sessionId) {
        const stripe = window.Stripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);
        await stripe.redirectToCheckout({ sessionId: response.data.sessionId });
      } else {
        toastr.success("Order placed successfully!");
        navigate(ROUTES.home.name);
      }
    } catch (err) {
      if (err.response) toastr.error(err.response.data.message || "Failed to place order.");
      else if (err.request) toastr.error("Could not connect to the server.");
      else toastr.error("An unexpected error occurred.");
    }
  };

  if (loading) {
    return (
      <div>
        <Header />
        <div className="container mt-5 text-center">Loading...</div>
      </div>
    );
  }

  return (
    <div>
      <Header />
      <div className="order-container">
        <div className="order-summary-card">
          <h2 className="order-title">
            <i className="fa-solid fa-clipboard-list order-title-icon"></i>
            Order Summary
          </h2>
          <div className="row">
            <div className="col-md-7">
              <h4 className="order-section">
                <i className="fa-solid fa-user"></i> Customer Details
              </h4>
              <form className="order-form" onSubmit={handlePlaceOrder}>
                <div className="order-input-group">
                  <i className="fa-solid fa-id-card"></i>
                  <input
                    type="text"
                    className="order-input"
                    placeholder="First Name"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="order-input-group">
                  <i className="fa-solid fa-location-dot"></i>
                  <input
                    type="text"
                    className="order-input"
                    placeholder="Second Name"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="order-input-group">
                  <i className="fa-solid fa-phone"></i>
                  <input
                    type="tel"
                    className="order-input"
                    placeholder="Phone Number"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <button type="submit" className="order-btn">
                  <i className="fa-solid fa-check"></i> Place Order
                </button>
              </form>
            </div>
            <div className="col-md-5">
              <h4 className="order-section">
                <i className="fa-solid fa-cart-shopping"></i> Cart Summary
              </h4>
              <ul className="order-list-group">
                {cartItems.map((item) => (
                  <li key={item._id} className="order-list-group-item">
                    <div>
                      <h6 className="my-0">{item.product.name}</h6>
                      <small className="text-muted">Quantity: {item.quantity}</small>
                    </div>
                    <span className="order-price">${(item.product.price * item.quantity).toFixed(2)}</span>
                  </li>
                ))}
                <li className="order-list-group-item order-total">
                  <span>Total (USD)</span>
                  <strong>${total.toFixed(2)}</strong>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderSummary;