import React, { useState, useEffect } from 'react';
import Header from '../../components/Header.js';
import axiosInstance from '../../api/axiosInstance.js';
import { address } from '../../App.js';
import { useNavigate } from 'react-router-dom';
import ROUTES from '../../navigation/Routes.js';
import swal from 'sweetalert';
import toastr from 'toastr';
import 'toastr/build/toastr.min.css';
import "./ShoppingCart.css";

function inrFormat(amount) {
  if (isNaN(amount)) return "₹0";
  return "₹" + Number(amount).toLocaleString("en-IN", { minimumFractionDigits: 2 });
}

function ShoppingCart() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get(address("cart"));
      setCartItems(response.data.cart || []);
      setLoading(false);
    } catch (err) {
      console.error("Error fetching cart items:", err);
      toastr.error("Failed to load cart items. Please try again later.");
      setLoading(false);
    }
  };

  const handleQuantityChange = async (cartId, type) => {
    try {
      let response;
      if (type === 'increase') {
        response = await axiosInstance.put(address("incProdCount"), { cartId });
      } else {
        response = await axiosInstance.put(address("decProdCount"), { cartId });
      }
      if (response.status === 200) {
        toastr.success("Quantity updated successfully!");
        fetchCartItems();
      }
    } catch (err) {
      console.error("Error updating quantity:", err);
      toastr.error("Failed to update quantity. Please try again.");
    }
  };

  const handleRemoveItem = async (cartId) => {
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this item!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then(async (willDelete) => {
      if (willDelete) {
        try {
          const response = await axiosInstance.delete(address("deleteProd"), { data: { cartId } });
          if (response.status === 200) {
            toastr.success("Item removed successfully!");
            fetchCartItems();
          }
        } catch (err) {
          console.error("Error removing item:", err);
          toastr.error("Failed to remove item. Please try again.");
        }
      }
    });
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => {
      if (item.product) {
        return total + item.product.price * item.quantity;
      }
      return total;
    }, 0);
  };

  if (loading) {
    return (
      <div>
        <Header />
        <div className="cart-main text-center">Loading cart...</div>
      </div>
    );
  }

  return (
    <div>
      <Header />
      <div className="cart-main">
        <h2 className="cart-heading">Hungry Cart</h2>
        {cartItems.length === 0 ? (
          <div className="empty-cart-card">
            <span>Your cart is empty.</span>
          </div>
        ) : (
          <>
            <div className="cart-items-grid">
              {cartItems.map((item) =>
                !item.product ? (
                  <div className="cart-item-card" key={item._id}>
                    <div className="cart-item-missing">
                      This product is no longer available.
                    </div>
                  </div>
                ) : (
                  <div className="cart-item-card" key={item._id}>
                    
                    {/* ❌ IMAGE BOX REMOVED */}

                    <div className="cart-item-details">
                      <div className="cart-item-title">{item.product.name}</div>
                      <div className="cart-item-price">{inrFormat(item.product.price)}</div>
                    </div>

                    <div className="cart-item-qty">
                      <button
                        className="cart-qty-btn"
                        onClick={() => handleQuantityChange(item._id, 'decrease')}
                        disabled={item.quantity <= 1}
                      >
                        -
                      </button>
                      <span className='cart-item-qty-num'>{item.quantity}</span>
                      <button
                        className="cart-qty-btn"
                        onClick={() => handleQuantityChange(item._id, 'increase')}
                      >
                        +
                      </button>
                    </div>

                    <div className="cart-item-subtotal">
                      {inrFormat(item.product.price * item.quantity)}
                    </div>

                    <button
                      className="cart-remove-btn"
                      onClick={() => handleRemoveItem(item._id)}
                    >
                      Remove
                    </button>
                  </div>
                )
              )}
            </div>

            <div className="cart-summary-card">
              <div className="cart-total-row">
                <span className="cart-total-label">Grand Total:</span>
                <span className="cart-total-value">{inrFormat(calculateTotal())}</span>
              </div>
              <button
                className="cart-checkout-btn"
                onClick={() => navigate(ROUTES.orderSummary.name)}
              >
                Proceed to Checkout
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default ShoppingCart;
