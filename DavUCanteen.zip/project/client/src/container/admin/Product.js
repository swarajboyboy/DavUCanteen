import React, { useEffect, useState } from "react";
import Header from "../../components/Header.js";
import { useLocation } from "react-router-dom";
import axios from "../../api/axiosInstance.js";
import { address } from "../../App.js";
import toastr from "toastr";
import swal from "sweetalert";
import "./Product.css";

function useQuery() {
  const { search } = useLocation();
  return React.useMemo(() => new URLSearchParams(search), [search]);
}

// Inline icons; swap with your icons if you wish
const EditIcon = () => (
  <svg width="20" height="20" fill="#0050b2" viewBox="0 0 16 16"><path d="M13.498 1.795a1.17 1.17 0 0 1 1.66 1.661l-.94.94-1.66-1.66.94-.941zm-1.04 1.818-8.073 8.073a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l8.073-8.074-1.66-1.66z"/></svg>
);
const DeleteIcon = () => (
  <svg width="20" height="20" fill="#c22947" viewBox="0 0 16 16"><path d="M6.5 1a1 1 0 0 1 1 1h1a1 1 0 0 1 1-1h2A2.5 2.5 0 0 1 15 3.5V4H1v-.5A2.5 2.5 0 0 1 3.5 1h2zm8 4H1v8.5A2.5 2.5 0 0 0 3.5 16h9A2.5 2.5 0 0 0 15 13.5V5z"/></svg>
);

function Product() {
  const query = useQuery();
  const [products, setProducts] = useState(null);
  const [productId, setProductId] = useState(null);
  const [form, setForm] = useState({
    name: "",
    images: [],
    departmentId: query.get("id"),
    price: "",
    description: "",
    quantity: "10",
  });
  const [formError, setFormError] = useState({
    name: "",
    image: "",
    price: "",
    description: "",
    quantity: "",
  });
  const [preview, setPreview] = useState([]);

  useEffect(() => {
    getProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function getProducts() {
    try {
      axios.get(address(`products/${query.get("id")}`)).then((d) => {
        setProducts(d.data);
      });
    } catch (error) {
      alert(error.message);
    }
  }

  const changeHandler = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const imagehandler = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      const newPreviews = files.map((file) => URL.createObjectURL(file));
      setPreview(newPreviews);
      setForm((prevForm) => ({
        ...prevForm,
        images: files,
      }));
    } else {
      setPreview([]);
      setForm((prevForm) => ({
        ...prevForm,
        images: [],
      }));
    }
  };

  function resetForm() {
    setForm({
      name: "",
      images: [],
      price: "",
      description: "",
      quantity: "10",
      departmentId: query.get("id"),
    });
    setFormError({
      name: "",
      image: "",
      price: "",
      description: "",
      quantity: "",
    });
  }

  function handleClick() {
    let errors = false;
    const name = (form.name || "").trim();
    const price = (form.price || "").trim();
    const description = (form.description || "").trim();
    const quantity = String(form.quantity || "").trim();

    let error = {
      name: "",
      image: "",
      price: "",
      description: "",
      quantity: "",
    };

    if (name.length === 0) {
      errors = true;
      error.name = "Item name must be there";
    }

    if (form.images.length === 0 && !productId) {
      errors = true;
      error.image = "Image must be uploaded";
    }

    if (price.length === 0) {
      errors = true;
      error.price = "Item price must be there";
    }

    if (description.length === 0) {
      errors = true;
      error.description = "Item description must be there";
    }

    if (quantity.length === 0) {
      errors = true;
      error.quantity = "Item quantity must be there";
    }

    setFormError(error);

    if (!errors) {
      productId ? updateProduct() : saveProduct();
    }
  }

  function saveProduct() {
    try {
      let formData = new FormData();
      formData.append("name", form.name);
      formData.append("description", form.description);
      formData.append("price", form.price);
      formData.append("quantity", form.quantity);
      formData.append("departmentId", form.departmentId);

      form.images.forEach((image) => {
        formData.append("images", image, image.name);
      });

      axios
        .post(address("product"), formData, {
          "content-type": "multipart/form-data",
        })
        .then((d) => {
          toastr.success(d.data.message);
          getProducts();
          resetForm();
          setPreview([]);
        });
    } catch (error) {
      toastr.error(error.message);
      console.error(error);
    }
  }

  function updateProduct() {
    try {
      axios
        .putForm(address("product"), {
          name: form.name,
          images: form.images,
          id: productId,
          description: form.description,
          price: form.price,
          quantity: form.quantity,
        })
        .then((d) => {
          toastr.success(d.data.message);
          getProducts();
          resetForm();
          setProductId(null);
          setPreview([]);
        });
    } catch (error) {
      toastr.error(error?.message);
    }
  }

  function deleteProduct(id) {
    try {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          axios.delete(address(`product/${id}`)).then((d) => {
            toastr.success(d.data.message);
            getProducts();
          });
        } else {
          swal("Your record is safe!");
        }
      });
    } catch (error) {
      toastr.error(error?.message);
    }
  }

  // Product Cards Grid
  function renderProductsCards() {
    return (
      <div>
        <h2 className="product-section-heading">Products</h2>
        <div className="product-cards-section">
          {products?.map((item) => (
            <div className="product-card" key={item._id}>
              <img
                className="product-img"
                src={address(item.images[0])}
                alt={item.name}
              />
              <div className="product-title">{item.name}</div>
              <div className="product-desc">{item.description}</div>
              <div className="product-priceqty">
                <span className="product-price">₹{item.price}</span>
                <span className="product-qty">Qty: {item.quantity}</span>
              </div>
              <div className="product-actions-row">
                <button
                  className="icon-btn edit-btn"
                  title="Edit"
                  onClick={() => {
                    setProductId(item._id);
                    setForm({
                      ...form,
                      name: item.name,
                      price: String(item.price ?? ""),
                      description: item.description ?? "",
                      quantity: String(item.quantity ?? ""),
                    });

                    if (item.images && item.images.length > 0) {
                      const existingPreviews = item.images.map((img) =>
                        address(img)
                      );
                      setPreview(existingPreviews);
                    } else {
                      setPreview([]);
                    }
                  }}
                >
                  <EditIcon />
                </button>
                <button
                  className="icon-btn delete-btn"
                  title="Delete"
                  onClick={() => {
                    deleteProduct(item._id);
                  }}
                >
                  <DeleteIcon />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <Header />

      {renderProductsCards()}

      <div className="form-section">
        <div className="form-card">
          <div className="form-card-title">
            {productId ? "Update Product" : "Add Items"}
          </div>
          <div className="form-group row">
            <label className="font-weight-bold">Meal Name</label>
            <b className="form-control" style={{ background: "#fbfbff" }}>{query.get("name")}</b>
          </div>
          <div className="row">
            <div className="form-group col-6">
              <label className="font-weight-bold ">Item Name</label>
              <input
                type="text"
                className="form-control"
                name="name"
                onChange={changeHandler}
                value={form.name}
              />
              <p className="text-danger">{formError.name}</p>
            </div>
            <div className="form-group col-6">
              <label className="font-weight-bold">Price</label>
              <input
                className="form-control"
                type="text"
                onChange={changeHandler}
                value={form.price}
                name="price"
              />
              <p className="text-danger">{formError.price}</p>
            </div>
          </div>
          <div className="row">
            <div className="col-6">
              <div className="form-group">
                <label className="font-weight-bold">Quantity</label>
                <input
                  className="form-control"
                  type="text"
                  onChange={changeHandler}
                  value={form.quantity}
                  name="quantity"
                />
                <p className="text-danger">{formError.quantity}</p>
              </div>
              <div className="form-group row">
                <label className="font-weight-bold ">Item Image</label>
                <input
                  type="file"
                  className="form-control"
                  name="images"
                  onChange={imagehandler}
                  multiple
                />
                <p className="text-danger">{formError.image}</p>
              </div>
            </div>
            <div className="col-6">
              <div className="form-group">
                <label className="font-weight-bold">Description</label>
                <textarea
                  className="form-control"
                  name="description"
                  value={form.description}
                  onChange={changeHandler}
                ></textarea>
                <p className="text-danger">{formError.description}</p>
              </div>
            </div>
          </div>
          <div className="form-actions text-right">
            <button
              className="btn btn-info"
              onClick={handleClick}
            >
              {productId ? "Update" : "Save"}
            </button>
            <button
              className="btn btn-danger mx-2"
              onClick={() => {
                resetForm();
                setProductId(null);
                setPreview([]);
              }}
            >
              Clear
            </button>
          </div>
        </div>
        <div className="preview-section">
          <div className="img-preview-box-multi">
            {preview && preview.length > 0 ? (
              preview.map((imgSrc, idx) => (
                <img
                  key={idx}
                  src={imgSrc}
                  alt={`Product preview ${idx+1}`}
                  style={{
                    maxWidth: "90px",
                    maxHeight: "90px",
                    objectFit: "cover",
                    borderRadius: "0.7em",
                    margin: "0.23em"
                  }}
                />
              ))
            ) : (
              <span style={{ color: "#babdc3", fontSize: "1em" }}>No Image</span>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default Product;