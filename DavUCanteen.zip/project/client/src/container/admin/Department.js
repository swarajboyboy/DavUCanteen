import React, { useEffect, useMemo, useState } from 'react'
import Header from '../../components/Header.js'
import { useLocation, useNavigate } from 'react-router-dom'
import axios from '../../api/axiosInstance.js';
import { address } from '../../App.js';
import toastr from 'toastr'
import swal from 'sweetalert'
import ROUTES from '../../navigation/Routes.js';
import "./Department.css";

function useQuery(){
  const {search} = useLocation();
  return useMemo(()=>
    new URLSearchParams(search),[search]
  );
}

// Simple SVG icons
const EditIcon = () => (
  <svg width="22" height="22" fill="#22315a" viewBox="0 0 16 16">
    <path d="M13.498 1.795a1.17 1.17 0 0 1 1.66 1.661l-.94.94-1.66-1.66.94-.941zm-1.04 1.818-8.073 8.073a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l8.073-8.074-1.66-1.66z"/>
  </svg>
);
const DeleteIcon = () => (
  <svg width="22" height="22" fill="#c22947" viewBox="0 0 16 16">
    <path d="M6.5 1a1 1 0 0 1 1 1h1a1 1 0 0 1 1-1h2A2.5 2.5 0 0 1 15 3.5V4H1v-.5A2.5 2.5 0 0 1 3.5 1h2zm8 4H1v8.5A2.5 2.5 0 0 0 3.5 16h9A2.5 2.5 0 0 0 15 13.5V5z"/>
  </svg>
);

function Department() {
  const query = useQuery();
  const [departments, setDepartments] = useState(null);
  const [departmentId, setDepartmentId] = useState(null);
  const [form, setForm] = useState({
    name: "",
    image: null,
    universityId: query.get("id")
  });
  const [formError, setFormError] = useState({ name: "", image: "" });
  const navigate = useNavigate();
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    getDepartments();
    // eslint-disable-next-line
  }, []);

  function getDepartments() {
    try {
      axios.get(address(`department/${query.get("id")}`)).then((d) => {
        setDepartments(d.data);
      });
    } catch (error) {
      alert(error.message);
    }
  }

  const changeHandler = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  const imagehandler = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      setForm((prevForm) => ({
        ...prevForm,
        image: file,
      }));
    } else {
      setPreview(null);
      setForm((prevForm) => ({
        ...prevForm,
        image: null,
      }));
    }
  };

  function resetForm() {
    setForm({ name: "", image: null });
    setPreview(null);
    setDepartmentId(null);
    setFormError({ name: "", image: "" });
  }

  function handleClick(e) {
    e?.preventDefault();
    let errors = false;
    let error = { name: "", image: "" };
    if (form.name.trim().length === 0) {
      errors = true;
      error = { ...error, name: "Meal name must be there" };
    }
    if (form.image == null && !departmentId) {
      errors = true;
      error = { ...error, image: "Image must be uploaded" };
    }
    setFormError(error);

    if (!errors)
      departmentId ? updateDepartment() : saveDepartments();
  }

  function saveDepartments() {
    try {
      let formData = new FormData();
      formData.append("name", form.name);
      formData.append("image", form.image, form.image?.name);
      formData.append("universityId", query.get("id"));
      axios
        .post(address("department"), formData, {
          "content-type": "multipart/form-data",
        })
        .then((d) => {
          toastr.success(d.data.message);
          getDepartments();
          resetForm();
        });
    } catch (error) {
      toastr.error(error.message);
      console.error(error);
    }
  }

  function updateDepartment() {
    try {
      axios
        .putForm(address("department"), {
          name: form.name,
          image: form.image,
          id: departmentId,
        })
        .then((d) => {
          toastr.success(d.data.message);
          getDepartments();
          resetForm();
        });
    } catch (error) {
      toastr.error(error?.message);
    }
  }

  function deleteDepartment(id) {
    try {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          axios.delete(address(`department/${id}`)).then((d) => {
            toastr.success(d.data.message);
            getDepartments();
          });
        } else {
          swal("Your record is safe!");
        }
      });
    } catch (error) {
      toastr.error(error?.message)
    }
  }

  // CARD GRID FOR "Meals"
  function renderDepartmentsCards() {
    return (
      <div>
        <h2 className="department-section-heading">Meals</h2>
        <div className="department-cards-row">
          {departments?.map((item) => (
            <div className="department-card" key={item._id}>
              <img
                className="department-img"
                src={address(item.image)}
                alt={item.name}
              />
              <div className="department-title">{item.name}</div>
              <button className="department-additem-btn"
                onClick={() => {
                  navigate(ROUTES.productAdmin.name + "?id=" + item._id + "&name=" + item.name)
                }}
              >
                Add Item
              </button>
              <div className="department-actions">
                <button
                  className="icon-btn edit-btn"
                  onClick={() => {
                    setDepartmentId(item._id);
                    setForm({ ...form, name: item.name, image: null });
                    setPreview(address(item.image));
                  }}
                  title="Edit"
                >
                  <EditIcon />
                </button>
                <button
                  className="icon-btn delete-btn"
                  onClick={() => {
                    deleteDepartment(item._id);
                  }}
                  title="Delete"
                >
                  <DeleteIcon />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <Header />
      {renderDepartmentsCards()}
      <div className="department-form-area">
        <div className="department-form-inner">
          <form
            className="department-form-card"
            autoComplete="off"
            onSubmit={handleClick}
          >
            <h3>{departmentId ? "Update Meal" : "Add Meal"}</h3>
            <label>Shop Name</label>
            <b className="form-control" style={{ background: "#fbfbff" }}>{query.get("name")}</b>
            <label>Meal Name</label>
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={changeHandler}
              autoComplete="off"
            />
            <p className="text-danger">{formError.name}</p>
            <label>Meal Image</label>
            <input
              type="file"
              name="image"
              onChange={imagehandler}
              accept="image/*"
            />
            <p className="text-danger">{formError.image}</p>
            <div className="department-form-actions">
              <button className="department-form-btn save" type="submit">
                {departmentId ? "Update" : "Save"}
              </button>
              <button
                type="button"
                className="department-form-btn clear"
                onClick={resetForm}
              >
                Clear
              </button>
            </div>
          </form>
          <div className="department-preview-box">
            {preview ? (
              <img src={preview} alt="Meal preview" />
            ) : (
              <span className="no-image">No Image</span>
            )}
          </div>
        </div>
      </div>
    </>
  );

}

export default Department;