import React, { useEffect, useState } from "react";
import Header from "../../components/Header.js";
import { useNavigate } from "react-router-dom";
import { address } from "../../App.js";
import axiosInstance from "../../api/axiosInstance.js";
import toastr from "toastr";
import swal from "sweetalert";
import ROUTES from "../../navigation/Routes.js";
import "./University.css";

// Icons as inline SVG (or you could use react-icons)
const EditIcon = () => (
  <svg width="20" height="20" fill="#0050b2" viewBox="0 0 16 16"><path d="M13.498 1.795a1.17 1.17 0 0 1 1.66 1.661l-.94.94-1.66-1.66.94-.941zm-1.04 1.818-8.073 8.073a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l8.073-8.074-1.66-1.66z"/></svg>
);
const DeleteIcon = () => (
  <svg width="20" height="20" fill="#c22947" viewBox="0 0 16 16"><path d="M6.5 1a1 1 0 0 1 1 1h1a1 1 0 0 1 1-1h2A2.5 2.5 0 0 1 15 3.5V4H1v-.5A2.5 2.5 0 0 1 3.5 1h2zm8 4H1v8.5A2.5 2.5 0 0 0 3.5 16h9A2.5 2.5 0 0 0 15 13.5V5z"/></svg>
);

function University() {
  const [universities, setUniversities] = useState(null);
  const [universityId, setUniversityId] = useState(null);
  const [form, setForm] = useState({ name: "", image: null });
  const [formError, setFormError] = useState({ name: "", image: "" });
  const navigate = useNavigate();
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    getUniversities();
  }, []);

  function getUniversities() {
    try {
      axiosInstance.get(address("university")).then((d) => {
        setUniversities(d.data.uniData);
      });
    } catch (error) {
      alert(error.message);
    }
  }

  const changeHandler = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const imagehandler = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      setForm((prevForm) => ({
        ...prevForm,
        image: file,
      }));
    } else {
      setPreview(null);
      setForm((prevForm) => ({
        ...prevForm,
        image: null,
      }));
    }
  };

  function resetForm() {
    setForm({ name: "", image: null });
  }

  function handleClick() {
    let errors = false;
    let error = { name: "", image: "" };
    if (form.name.trim().length === 0) {
      errors = true;
      error = { ...error, name: "Shop name must be there" };
    }
    if (form.image == null && !universityId) {
      errors = true;
      error = { ...error, image: "Image Must be uploaded" };
    }
    setFormError(error);

    if (!errors)
      universityId ? updateUniversity() : saveUniversities();
  }

  function saveUniversities() {
    try {
      let formData = new FormData();
      formData.append("name", form.name);
      formData.append("image", form.image, form.image.name);
      axiosInstance
        .post(address("university"), formData, {
          "content-type": "multipart/form-data",
        })
        .then((d) => {
          toastr.success(d.data.message);
          getUniversities();
          resetForm();
        });
    } catch (error) {
      toastr.error(error.message);
      console.error(error);
    }
  }

  function updateUniversity() {
    try {
      const formData = new FormData();
      formData.append("name", form.name);
      if (form.image) {
        formData.append("image", form.image);
      }
      formData.append("id", universityId);

      axiosInstance
        .put(address("university"), formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((d) => {
          toastr.success(d.data.message);
          getUniversities();
          resetForm();
          setUniversityId(null);
          setPreview(null);
        });
    } catch (error) {
      toastr.error(error?.response?.data?.message || error.message);
    }
  }

  function deleteUniversity(id) {
    try {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          axiosInstance.delete(address(`university/${id}`)).then((d) => {
            toastr.success(d.data.message);
            getUniversities();
          });
        } else {
          swal("Your record is safe!");
        }
      });
    } catch (error) {
      toastr.error(error?.message)
    }
  }

  function renderUniversitiesCards() {
    return (
      <div>
        <h2 className="shop-section-heading">Shops</h2>
        <div className="shop-cards-section">
          {universities?.map((item) => (
            <div className="shop-card" key={item._id}>
              <img
                className="shop-img"
                src={address(item.image)}
                alt={item.name}
              />
              <div className="shop-title">{item.name}</div>
              <button
                className="add-menu-btn"
                onClick={() => {
                  navigate(ROUTES.departmentAdmin.name + "?id=" + item._id + "&name=" + item.name)
                }}
              >
                Add Menu
              </button>
              <div className="shop-actions-row">
                <button
                  className="icon-btn edit-btn"
                  title="Edit"
                  onClick={() => {
                    setUniversityId(item._id);
                    setForm({ ...form, name: item.name });
                    setPreview(address(item.image));
                  }}
                >
                  <EditIcon />
                </button>
                <button
                  className="icon-btn delete-btn"
                  title="Delete"
                  onClick={() => {
                    deleteUniversity(item._id)
                  }}
                >
                  <DeleteIcon />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <Header />
      {renderUniversitiesCards()}

      <div className="form-section">
        <div className="form-card">
          <div className="form-card-title">
            {universityId ? "Update Store" : "Add Shop"}
          </div>
          <div className="form-group">
            <label>Shop Name</label>
            <input
              type="text"
              className="form-control"
              name="name"
              onChange={changeHandler}
              value={form.name}
            />
            <p className="text-danger">{formError.name}</p>
          </div>
          <div className="form-group">
            <label>Shop Image</label>
            <input
              type="file"
              className="form-control"
              name="image"
              onChange={imagehandler}
              accept="image/*"
            />
            <p className="text-danger">{formError.image}</p>
          </div>
          <div className="form-actions">
            <button
              className="btn btn-info"
              onClick={handleClick}
            >
              {universityId ? "Update" : "Save"}
            </button>
            <button
              className="btn btn-danger"
              onClick={() => {
                resetForm();
                setUniversityId(null)
                setPreview(null);
              }}
            >
              Clear
            </button>
          </div>
        </div>
        <div className="preview-section">
          <div className="img-preview-box">
            {preview ? (
              <img src={preview} alt="Preview" />
            ) : (
              <span style={{color: "#b4b9c6", fontSize: "0.97em"}}>No Image</span>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default University;