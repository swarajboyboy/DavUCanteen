import React, { useEffect, useState } from "react";
import Header from "../../../components/Header";
import axios from "../../../api/axiosInstance.js";
import { address } from "../../../App";
import { useLocation, useNavigate } from "react-router-dom";
import ROUTES from "../../../navigation/Routes";
import $ from "jquery";
import 'datatables.net-dt';
import './UserDepartment.css';

function useQuery() {
  const { search } = useLocation();
  return React.useMemo(() => new URLSearchParams(search), [search]);
}

function UserDepartment() {
  const [departments, setDepartments] = useState([]);
  const [filtered, setFiltered] = useState([]);   // <-- NEW
  const [searchTerm, setSearchTerm] = useState(""); // <-- NEW

  const query = useQuery();
  const universityName = query.get("name");
  const universityId = query.get("id");
  const navigate = useNavigate();

  useEffect(() => {
    GetDepartments();
  }, [universityId]);

  const GetDepartments = () => {
    axios.get(address("department/" + universityId))
      .then((d) => {
        setDepartments(d.data);
        setFiltered(d.data);       // initial copy
      })
      .catch(error => {
        console.error("Error fetching departments:", error);
        setDepartments([]);
        setFiltered([]);
      });
  };

  // 🔍 SEARCH FILTER (runs whenever searchTerm changes)
  useEffect(() => {
    const s = searchTerm.toLowerCase();
    const result = departments.filter((item) =>
      item.name.toLowerCase().includes(s)
    );
    setFiltered(result);
  }, [searchTerm, departments]);


  // DATATABLE RENDER
  useEffect(() => {
    if ($.fn.dataTable.isDataTable('#dataTable')) {
      $('#dataTable').DataTable().destroy();
    }

    if (filtered.length > 0) {
      $("#dataTable").DataTable({
        data: filtered,
        columns: [
          {
            render: function (data, type, row) {
              return `
                <div class="userdept-card-wrapper">
                  <div class="userdept-card">
                    <div class="userdept-card-imgbox">
                      <img class="userdept-card-img" alt="Department image" src="${address(row.image)}" />
                      <span class="userdept-card-badge">
                        <i class="fa-solid fa-bowl-food"></i>
                      </span>
                    </div>
                    <div class="userdept-card-body">
                      <h5 class="userdept-card-title">
                        <i class="fa-solid fa-building"></i> ${row.name}
                      </h5>
                      <button
                        class="userdept-btn-go go-to-products-btn"
                        data-id="${row._id}"
                        data-name="${row.name}">
                        <i class="fa-solid fa-concierge-bell"></i> Go For This Meal
                      </button>
                    </div>
                  </div>
                </div>
              `;
            },
          },
        ],
        destroy: true,
        paging: false,
        searching: false,
        info: false,
        ordering: false,
      });

      $('#dataTable tbody')
        .off("click", ".go-to-products-btn")
        .on("click", ".go-to-products-btn", function () {
          const id = $(this).data("id");
          const name = $(this).data("name");
          navigate(ROUTES.productUser.name + "?id=" + id + "&name=" + name);
        });
    }

  }, [filtered, navigate]);

  return (
    <div className="userdept-bg">
      <Header />
      <div className="container userdept-container mt-4">

        <h2 className="userdept-title mb-4">
          <span className="userdept-title-icon">
            <i className="fa-solid fa-store"></i>
          </span>
          <span className="userdept-title-red">Meal Junction</span> {universityName}
        </h2>

        {/* 🔍 SEARCH INPUT ADDED */}
        <div className="row mb-3">
          <div className="col-md-6 mx-auto">
            <input
              type="text"
              className="form-control userdept-search"
              placeholder="Search Your Fav Meal..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="alert alert-info text-center userdept-alert">
            <i className="fa-regular fa-clock"></i>
            “No Meal Found”
          </div>
        ) : (
          <table id="dataTable" className="display userdept-table" style={{ width: "100%" }}>
            <thead><tr></tr></thead>
            <tbody className="d-flex"></tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default UserDepartment;
