import React, { useEffect, useState } from "react";
import Header from "../../../components/Header";
import $ from "jquery";
import { address } from "../../../App";
import { useLocation, useNavigate } from "react-router-dom";
import ROUTES from "../../../navigation/Routes";
import axios from "../../../api/axiosInstance.js"; // Use axiosInstance
import './UserProduct.css';

// --- INR Conversion Utility ---
const USD_TO_INR = 83; // Change as needed
function priceInRupees(dollar) {
  return Math.round(dollar * USD_TO_INR);
}

function useQuery() {
  const { search } = useLocation();
  return React.useMemo(() => new URLSearchParams(search), [search]);
}

function UserProduct() {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();
  const query = useQuery();
  const departmentName = query.get("name"); // Get department name from query
  const departmentId = query.get("id"); // Get department ID from query

  useEffect(() => {
    GetProducts();
  }, [departmentId]);

  const GetProducts = () => {
    axios.get(address(`products/${departmentId}`)).then((d) => {
      setProducts(d.data);
    }).catch((er) => {
      console.error("Error fetching products:", er);
      setProducts([]);
    });
  }

  useEffect(() => {
    if (products.length > 0) {
      // Destroy existing DataTable instance if exists
      if ($.fn.DataTable.isDataTable('#dataTable')) {
        $('#dataTable').DataTable().destroy();
      }

      $("#dataTable").DataTable({
        data: products,
        columns: [
          {
            render: function (data, type, row) {
              // Price INR Calculation
              const priceINR = priceInRupees(row.price).toLocaleString();

              return `
                <div class="userp-card-wrapper">
                  <div class="userp-card">
                    <img class="userp-card-img" alt="Product image" src="${address(row.images[0])}" />
                    <div class="userp-card-body">
                      <div class="userp-title-row">
                        <h5 class="userp-card-title">${row.name}</h5>
                        <span class="userp-price">₹${priceINR}</span>
                      </div>
                      <div class="userp-price-usd">($${row.price.toFixed(2)} USD)</div>
                      <p class="userp-desc">${row.description}</p>
                      <button
                        class="userp-btn-details go-to-products-btn"
                        data-id="${row._id}">
                        Details
                      </button>
                    </div>
                  </div>
                </div>
                `;
            }
          },
        ],
        destroy: true, // Destroy existing table if any
        paging: false,
        searching: false,
        info: false,
        ordering: false,
      });

      // Event listener for Details button
      $("#dataTable tbody").off("click", ".go-to-products-btn").on("click", ".go-to-products-btn", function () {
        const id = $(this).data("id");
        navigate(ROUTES.productDetail.name + "?id=" + id, { state: { departmentId: query.get("id") } });
      });
    } else if ($.fn.DataTable.isDataTable('#dataTable')) {
      $('#dataTable').DataTable().destroy();
    }
  }, [products, navigate]);

  return (
    <div className="userp-bg">
      <Header />
      <div className="container userp-container mt-4">
        <h2 className="userp-title mb-4">Meals in <span className="userp-title-red">{departmentName}</span></h2>
        {products.length === 0 ? (
          <div className="alert alert-info text-center userp-alert">No Item available in this Shop.</div>
        ) : (
          <table id="dataTable" className="display userp-table" style={{ width: "100%" }}>
            <thead>
              <tr></tr>
            </thead>
            <tbody className="d-flex">
              {/* DataTables will populate this tbody */}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default UserProduct;