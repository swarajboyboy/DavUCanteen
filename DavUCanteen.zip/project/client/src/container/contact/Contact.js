import React, { useState } from "react";
import Header from "../../components/Header";
import "./Contact.css"; // <-- Add the CSS file below

function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setError("All fields are required.");
      setSuccess("");
      return;
    }
    setError("");
    setSuccess("Your message has been sent successfully!");
    // (Optional) Add backend request: axios.post("/api/contact", form);
  };

  return (
    <div className="contact-bg">
      <Header />
      <div className="contact-container">
        <h1 className="contact-title">
          <i className="fa-solid fa-envelope-open-text contact-title-icon"></i>
          Contact Us
        </h1>
        <form className="contact-form" onSubmit={handleSubmit}>
          {error && <p className="contact-error">{error}</p>}
          {success && <p className="contact-success">{success}</p>}

          <div className="contact-input-group">
            <i className="fa-solid fa-user"></i>
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={form.name}
              onChange={handleChange}
              className="contact-input"
            />
          </div>
          <div className="contact-input-group">
            <i className="fa-solid fa-at"></i>
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={form.email}
              onChange={handleChange}
              className="contact-input"
            />
          </div>
          <div className="contact-input-group contact-textarea-group">
            <i className="fa-solid fa-comment-dots"></i>
            <textarea
              name="message"
              placeholder="Write your message here..."
              value={form.message}
              onChange={handleChange}
              className="contact-textarea"
            ></textarea>
          </div>
          <button type="submit" className="contact-btn">
            <i className="fa-solid fa-paper-plane"></i> Send Message
          </button>
        </form>
      </div>
    </div>
  );
}

export default Contact;